// @flow

import DocsDecoratorEntityDataContainer from 'v2/docs/DocsDecoratorEntityDataContainer';
import {CompositeDecorator} from 'v2/docs/DraftJS';
import {findEntitiesForType} from 'v2/docs/DocsHelpers';

const entries = [];

module.exports = {

  // https://draftjs.org/docs/advanced-topics-decorators.html#compositedecorator
  register(decoratorType: string, Component: Function) {
    const strategy = findEntitiesForType.bind(null, decoratorType);
    const fn: Function = DocsDecoratorEntityDataContainer;
    entries.push({
      strategy: strategy,
      component: fn.bind(null, Component, decoratorType),
    });
  },

  get(): CompositeDecorator {
    return new CompositeDecorator(entries);
  },
};
