// @flow

// $FlowFixMe Flow doesn't know about this import
import DraftJS from 'draft-js';

module.exports = {
  ...DraftJS,
};
