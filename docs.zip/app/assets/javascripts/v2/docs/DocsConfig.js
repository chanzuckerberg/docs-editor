// @flow

import DocsAnnotation from 'v2/docs/DocsAnnotation';
import DocsBlockTypeToComponent from 'v2/docs/DocsBlockTypeToComponent';
import DocsBlockTypes from 'v2/docs/DocsBlockTypes';
import DocsDecorator from 'v2/docs/DocsDecorator';
import DocsDecoratorTypes from 'v2/docs/DocsDecoratorTypes';
import DocsExpandable from 'v2/docs/DocsExpandable';
import DocsImage from 'v2/docs/DocsImage';
import DocsLink from 'v2/docs/DocsLink';
import DocsMath from 'v2/docs/DocsMath';
import DocsTable from 'v2/docs/DocsTable';

function registerCustomBlocks(specs: Array<Array<any>>): void {
  specs.forEach(spec => {
    const [type, view] = spec;
    DocsBlockTypeToComponent.register(type, view);
  });
}

function registerDecorator(specs: Array<Array<any>>): void {
  specs.forEach(spec => {
    const [type, view] = spec;
    DocsDecorator.register(type, view);
  });
}

function init(): void {
  registerCustomBlocks([
    [DocsBlockTypes.DOCS_TABLE, DocsTable],
    [DocsBlockTypes.DOCS_EXPANDABLE, DocsExpandable],
  ]);

  // Register Decorator
  registerDecorator([
    [DocsDecoratorTypes.DOCS_ANNOTATION, DocsAnnotation],
    [DocsDecoratorTypes.DOCS_IMAGE, DocsImage],
    [DocsDecoratorTypes.DOCS_MATH, DocsMath],
    [DocsDecoratorTypes.LINK, DocsLink],
  ]);
}

module.exports = {
  init,
};
