// @flow
import keyMirror from 'v2/core/util/keyMirror';
module.exports = keyMirror({
  EDITOR_IN: null,
  EDITOR_OUT: null,
  EDITOR_REQUEST_UPDATE_ENTITY_DATA: null,
  LOAD: null,
});
