// @flow

import keyMirror from 'v2/core/util/keyMirror';

module.exports = keyMirror({
  DOCS_EXPANDABLE: null,
  DOCS_MATH: null,
  DOCS_TABLE: null,
});
